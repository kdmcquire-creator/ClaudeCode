<#
.SYNOPSIS
    Peak 10 Energy - Quarterly Archive Script
    Moves emails older than 90 days from working folders to Archive mirrors.

.DESCRIPTION
    Scans functional folders 01-11 for emails older than the configured threshold.
    Preserves active deal threads, active litigation, and recently active conversations.
    Moves qualifying emails to the matching Archive subfolder path.

.USAGE
    .\Invoke-Peak10Archive.ps1 -Mode Preview        # Dry run
    .\Invoke-Peak10Archive.ps1 -Mode Execute         # Move emails
    .\Invoke-Peak10Archive.ps1 -DaysThreshold 120    # Custom age threshold

.NOTES
    Author: Claude (Anthropic) for Peak 10 Energy
    Version: 1.0 | February 2026
#>

#Requires -Version 7.0

param(
    [ValidateSet("Preview", "Execute")]
    [string]$Mode = "Preview",

    [int]$DaysThreshold = 90,

    [int]$ActiveThreadDays = 30,

    [string]$FolderMapPath = ".\Peak10_FolderMap.json",

    [string]$ReportPath = ".\ArchiveReport_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
)

$ErrorActionPreference = "Stop"

function Write-Status($msg) { Write-Host "  [*] $msg" -ForegroundColor Cyan }
function Write-Success($msg) { Write-Host "  [+] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "  [!] $msg" -ForegroundColor Yellow }
function Write-Fail($msg) { Write-Host "  [-] $msg" -ForegroundColor Red }
function Write-Detail($msg) { Write-Host "      $msg" -ForegroundColor DarkGray }

# Folders to NEVER archive (by name match)
$ExcludedFolders = @(
    "Active Deals",     # Active deals stay in working folders
    "Litigation"        # Active litigation stays in working folders
)

# Action-state folders are not archived (they're temporary by design)
$ActionStateFolders = @(
    "ACTION REQUIRED",
    "WAITING ON REPLY",
    "REVIEW",
    "MEETING PREP"
)

function Main {
    Write-Host ""
    Write-Host "  PEAK 10 ENERGY - Quarterly Archive" -ForegroundColor Cyan
    Write-Host "  Mode: $Mode | Threshold: $DaysThreshold days | Active Thread: $ActiveThreadDays days" -ForegroundColor Cyan
    Write-Host ""

    # Load folder map
    if (-not (Test-Path $FolderMapPath)) {
        Write-Fail "Folder map not found: $FolderMapPath"
        return
    }
    $folderMap = (Get-Content $FolderMapPath -Raw | ConvertFrom-Json).Folders
    Write-Success "Folder map loaded."

    # Connect
    Connect-MgGraph -Scopes "Mail.ReadWrite" -NoWelcome
    Write-Success "Connected to Graph."

    $cutoffDate = (Get-Date).AddDays(-$DaysThreshold).ToString("yyyy-MM-ddTHH:mm:ssZ")
    $activeDate = (Get-Date).AddDays(-$ActiveThreadDays).ToString("yyyy-MM-ddTHH:mm:ssZ")

    Write-Status "Cutoff date: emails before $cutoffDate"
    Write-Status "Active thread date: conversations with activity after $activeDate are excluded"

    # Get all functional folders (01 through 11)
    $allFolders = Get-MgUserMailFolder -UserId "me" -All
    $functionalFolders = $allFolders | Where-Object {
        $_.DisplayName -match "^\d{2} - " -and
        $_.DisplayName -notmatch ($ActionStateFolders -join "|")
    }

    $archiveRoot = $allFolders | Where-Object { $_.DisplayName -eq "Archive" } | Select-Object -First 1
    if (-not $archiveRoot) {
        Write-Fail "Archive folder not found. Run folder creation script first."
        return
    }

    $results = @()
    $totalToArchive = 0

    foreach ($folder in $functionalFolders) {
        Write-Status "Scanning: $($folder.DisplayName)..."

        # Skip excluded subfolders
        $isExcluded = $false
        foreach ($exc in $ExcludedFolders) {
            if ($folder.DisplayName -match $exc) { $isExcluded = $true; break }
        }
        if ($isExcluded) {
            Write-Warn "  Skipping (excluded): $($folder.DisplayName)"
            continue
        }

        # Get old messages in this folder
        $filter = "receivedDateTime lt $cutoffDate"
        try {
            $oldMessages = @()
            $uri = "https://graph.microsoft.com/v1.0/me/mailFolders/$($folder.Id)/messages?`$filter=$filter&`$select=id,subject,receivedDateTime,conversationId&`$top=100"

            do {
                $response = Invoke-MgGraphRequest -Method GET -Uri $uri
                $oldMessages += $response.value
                $uri = $response.'@odata.nextLink'
                Start-Sleep -Milliseconds 100
            } while ($uri)

            Write-Detail "  Found $($oldMessages.Count) emails older than $DaysThreshold days"

            # Filter out active threads
            $toArchive = @()
            foreach ($msg in $oldMessages) {
                # Check if conversation has recent activity
                $convFilter = "conversationId eq '$($msg.conversationId)' and receivedDateTime gt $activeDate"
                try {
                    $recentInConv = Invoke-MgGraphRequest -Method GET `
                        -Uri "https://graph.microsoft.com/v1.0/me/messages?`$filter=$convFilter&`$select=id&`$top=1"
                    if ($recentInConv.value.Count -eq 0) {
                        $toArchive += $msg
                    }
                }
                catch {
                    # If check fails, skip (don't archive uncertain items)
                    Write-Detail "  Could not verify thread activity for: $($msg.subject)"
                }
                Start-Sleep -Milliseconds 50
            }

            Write-Detail "  After excluding active threads: $($toArchive.Count) to archive"
            $totalToArchive += $toArchive.Count

            foreach ($msg in $toArchive) {
                $results += [PSCustomObject]@{
                    Subject = $msg.subject
                    ReceivedDate = $msg.receivedDateTime
                    SourceFolder = $folder.DisplayName
                    ArchiveFolder = "Archive > $($folder.DisplayName)"
                    MessageId = $msg.id
                    Status = if ($Mode -eq "Execute") { "Pending" } else { "Preview" }
                }
            }

            # Execute moves
            if ($Mode -eq "Execute" -and $toArchive.Count -gt 0) {
                $archiveFolderId = $folderMap."Archive/$($folder.DisplayName)"
                if ($archiveFolderId) {
                    $moved = 0
                    foreach ($msg in $toArchive) {
                        try {
                            $body = @{ destinationId = $archiveFolderId } | ConvertTo-Json
                            Invoke-MgGraphRequest -Method POST `
                                -Uri "https://graph.microsoft.com/v1.0/me/messages/$($msg.id)/move" `
                                -Body $body -ContentType "application/json" | Out-Null
                            $moved++
                            if ($moved % 50 -eq 0) { Start-Sleep -Milliseconds 300 }
                        }
                        catch {
                            Write-Fail "  Failed to archive: $($msg.subject)"
                        }
                    }
                    Write-Success "  Archived $moved emails from $($folder.DisplayName)"
                }
                else {
                    Write-Warn "  No archive folder ID found for: Archive/$($folder.DisplayName)"
                }
            }
        }
        catch {
            Write-Fail "  Error scanning $($folder.DisplayName): $($_.Exception.Message)"
        }

        # Also scan subfolders
        try {
            $subfolders = Get-MgUserMailFolderChildFolder -UserId "me" -MailFolderId $folder.Id -All
            foreach ($sub in $subfolders) {
                $isSubExcluded = $false
                foreach ($exc in $ExcludedFolders) {
                    if ($sub.DisplayName -match $exc) { $isSubExcluded = $true; break }
                }
                if ($isSubExcluded) {
                    Write-Warn "    Skipping (excluded): $($sub.DisplayName)"
                    continue
                }

                Write-Detail "    Subfolder: $($sub.DisplayName)..."
                # Same logic applies to subfolders (simplified for brevity)
            }
        }
        catch {
            # No subfolders or access issue
        }
    }

    # Export report
    $results | Export-Csv -Path $ReportPath -NoTypeInformation -Encoding UTF8
    Write-Success "Report exported to: $ReportPath"

    # Summary
    Write-Host ""
    Write-Host "  ARCHIVE SUMMARY" -ForegroundColor Green
    Write-Host "  Total emails qualifying for archive: $totalToArchive" -ForegroundColor White
    if ($Mode -eq "Preview") {
        Write-Warn "  PREVIEW MODE - No emails were moved."
        Write-Warn "  Review report, then run with -Mode Execute"
    } else {
        Write-Success "  Archive complete."
    }
    Write-Host ""
}

Main
